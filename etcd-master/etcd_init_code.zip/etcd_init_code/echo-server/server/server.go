package server

import (
	"context"
	"etcd/echo"
	"fmt"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
	"google.golang.org/protobuf/types/known/timestamppb"
	"math/rand"
	"time"
)

type echoServer struct {
	echo.UnimplementedEchoServer
}

func NewEchoServer() echo.EchoServer {
	return &echoServer{}
}
func (s *echoServer) UnaryEcho(ctx context.Context, in *echo.EchoRequest) (*echo.EchoResponse, error) {
	fmt.Println("server recv: ", in.Message)
	return &echo.EchoResponse{
		Message: "hello client",
	}, nil
}

func (s *echoServer) UnaryLock(ctx context.Context, in *echo.EchoRequest) (*echo.EchoLockResponse, error) {
	fmt.Println("server recv: ", in.Message)
	randID := rand.Int63()
	start := time.Now()
	end := time.Now()
	return &echo.EchoLockResponse{
		Id:      randID,
		Message: "hello client",
		Start:   timestamppb.New(start),
		End:     timestamppb.New(end),
	}, nil
	return nil, status.Errorf(codes.Unimplemented, "method UnaryLock not implemented")
}
