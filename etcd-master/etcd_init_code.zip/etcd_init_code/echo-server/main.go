package main

import (
	"etcd/echo"
	"etcd/echo-server/server"
	"google.golang.org/grpc"
	"log"
	"net"
)

func main() {
	lis, err := net.Listen("tcp", "localhost:50051")
	if err != nil {
		log.Fatal(err)
	}
	s := grpc.NewServer()
	echoServer := server.NewEchoServer()
	echo.RegisterEchoServer(s, echoServer)
	err = s.Serve(lis)
	if err != nil {
		log.Fatal(err)
	}
}
